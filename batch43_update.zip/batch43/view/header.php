<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> HOME</title>
	<link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../css/product_show.css">
    <script type="text/javascript" src="../js/cart.js"></script>
    <img src="../img/cu.jpg"  style="width:100%; height: 150px;" alt="img">
</head>
</html>