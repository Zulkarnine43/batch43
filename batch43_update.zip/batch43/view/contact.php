
<body>

	<div id="head">
	<?php
       include("header.php");
	?>

	</div>

	<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>


	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>


	<div id="cont">
		  <?php
              include("contact_us_code.php");
	      ?>
</table>
	
	</div>
	
	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>
	
</body>

