<?php
$logout=$_GET['logout'];
if($logout==yes){
	session_start();
	session_destroy();
	header('Location:../view/index.php');
}


?>