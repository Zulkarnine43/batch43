<?php

include("../db/config.php");


//$directory= "img/";
//$filename = $_FILES['imagesupload']['name'];
//$filetmpname=$_FILES['imagesupload']['tmp_name'];
//move_uploaded_file($filetmpname,$directory.$filename);

if(isset($_POST['btn'])){
	
$product_name=$_POST['p_name'];

    $targetDir = "uploads/";
    $fileName = basename($_FILES['image']['name']);
    $targetFilePath = $targetDir.$fileName;
    move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath);

$Quentity=$_POST['quentity'];
$price=$_POST['price'];

$sql="INSERT INTO product_info (p_name,imagesupload,quentity,price) VALUES ('$product_name','$targetFilePath','$Quentity','$price')";

$result=mysqli_query($con,$sql);

}



header("Location:../view/view_product.php");


?>