<?php

include("../db/config.php");
$id=$_GET['id'];

$sql="SELECT * FROM cu_info WHERE id=$id";

$result=mysqli_query($con,$sql);


while($row=mysqli_fetch_array($result)){

	$id=$row['cu_id'];
	$name=$row['name'];
	$email=$row['email'];
	$gender=$row['gender'];
	$password=base64_decode($row['password']);

echo '

<input type="text" value="'.$id.'">



';





	}
?>