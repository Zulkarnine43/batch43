<?php
include("../db/config.php");
session_start();



if(empty($_SESSION['cart'])){
	$_SESSION['cart']=array();
}

 $value= array(
'p_name' =>$_POST["p_name"] ,
'quentity'=>$_POST["quentity"] ,
'price'=>$_POST["price"], 
);

array_push(	$_SESSION['cart'], $value);

header("Location:../view/checkout.php");

?>



  
 
 


