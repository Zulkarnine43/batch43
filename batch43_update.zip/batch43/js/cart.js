document.getElementById("item").style.display="none";

function item(){
    document.getElementById("item").style.display="block";

}

var i=["0"],totalPrice=["0"];

function myFunction(){
    i++;

    $n=document.getElementById("n").innerHTML;
    $p=Number(document.getElementById("p").innerHTML);

    document.getElementById("name").innerHTML= $n;
    document.getElementById("Quetity").innerHTML=i;
    document.getElementById("Price").innerHTML=i*$p;

    totalPrice=(i*$p);
    document.getElementById("total").innerHTML=totalPrice;
}