
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>


<div id="cont">

<?php

?>

 
   <table border="2px">
		<thead>
			<tr>
				<th>Name</th>
				<th>price(per pics)</th>
				<th>quentity</th>
				<th>total-price</th>
				<th>Action</th>
			</tr>
		</thead>
		
	  
		
		<?php  $sum=0 ;?>
		<?php foreach($_SESSION['cart'] as $key =>$value) { ?>
				<tbody>
			<tr>
				<td><?php echo $value['p_name']  ?></td>
				<td><?php echo $value['price']  ?></td>
				<td><?php echo $value['quentity']  ?></td>
				<td><?php echo $value['quentity']*$value['price']  ?></td>
				<td><?php $sum+=$value['quentity']*$value['price'] ?></td>
				
			</tr>
		</tbody>
		
		<?php } ?>
	</table>
	
	
	<div>

	<h2>Total_taka ::- <?php echo $sum ; ?>  </h2>

	
	<a href="checkout_page.php?name=<?php echo $value['p_name']  ?> && qty=<?php echo $value['quentity']  ?>" >Checkout</a>
	<a href=""  >Cancel order</a>
	
	
	
	 
	 
	
    </div>


</div>




<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

