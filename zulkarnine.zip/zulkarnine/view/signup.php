
<body>
<div id="head">
	<?php
       include("header.php");
	?>

	</div>

		<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>

	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>

<div id="cont">
<div style="margin-left:170px; margin-top:100px";>
	<form method="post" action="../db/signup_db.php">
		Name:<br><input type="text" name="name" placeholder="Enter your name ..."><br>
		Email:<br><input type="email" name="email" placeholder="Enter your email ..."><br>
		Gender:<br><input type="radio" name="gender" value="male">Male
		<input type="radio" name="gender" value="female">FeMale<br>
		password:<br><input type="password" name="password" placeholder="Enter your password ..."><br>
		Confirm_password:<br><input type="password"name="Confirm_password" placeholder="Enter your Confirm_password ..."><br>
		<input type="submit" name="btn"  value="Submit">
	</form>
	</div>

</div>


	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>

</body>

