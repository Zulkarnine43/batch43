
<body>
<div id="head">
	<?php
       include("header.php");
	?>

	</div>

		<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>

	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>

<div id="cont">
	<form method="post" action="../db/signup_db.php">
	<br><input type="hidden" name="product_id" value="<?php echo $_GET['name'] ?>"><br>
	<br><input type="hidden" name="quentity" value="<?php echo $_GET['qty'] ?>"><br>
		Name:<br><input type="text" name="name" placeholder="Enter your name ..."><br>
		Email:<br><input type="email" name="email" placeholder="Enter your email ..."><br>
		phone:<br><input type="tel" name="phone" placeholder="Enter your phone ..."><br>
		Address:<br><textarea rows="5" coloumn="40">Enter text here</textarea><br>
		Payment_type:<br><select>
		  <option >...select payment type...</option>
		  <option >Bkash</option>
		  <option>Cash on delivery</option>
		  <option>Paypal</option>
		</select><br>
		<input type="submit" name="btn"  value="Submit"><br>
	</form>

</div>


	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>

</body>

