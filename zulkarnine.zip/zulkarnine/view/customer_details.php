
<body>

	<div id="head">
	<?php
       include("header.php");
	?>

	</div>

	<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>


	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>


	<div id="cont">
		  <?php
               include("../model/view_cu_info.php");
	      ?>
</table>
	
	</div>
	
	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>
	
</body>

