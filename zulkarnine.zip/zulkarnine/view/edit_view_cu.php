
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>


<div id="cont">

 <?php

include("../db/config.php");
$id=$_GET['id'];

$sql="SELECT * FROM cu_info WHERE cu_id=$id";

$result=mysqli_query($con,$sql);


while($row=mysqli_fetch_array($result)){

	$id=$row['cu_id'];
	$name=$row['name'];
	$email=$row['email'];
	$gender=$row['gender'];
	$password=base64_decode($row['password']);
	$confirm_password=base64_decode($row['Confirm_password']);

echo '
<form method="post" action="../model/update_cu.php">
        Id:<br><input type="int" name="id" placeholder=" your Id ..." value="'.$id.'" readonly><br>
		Name:<br><input type="text" name="name" placeholder="update your name ..." value="'.$name.'"><br>
		Email:<br><input type="email" name="email" placeholder="update your email ..." value="'.$email.'"><br>
		Password:<br><input type="password"name="password" placeholder="update your password ..." value="'.$password.'"><br>
	    Confirm_Password:<br><input type="password"name="Confirm_password" placeholder="update your Confirm_Password ..." value="'.$confirm_password.'"><br>
		<input type="submit" name="btn"  value="update">
	</form>

';





	}
?>


</div>




<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

