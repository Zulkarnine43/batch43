


<body>
<div id="head">
	<?php
       include("header.php");
	?>

	</div>

		<div id="menu"> 
	<?php
       include("menu.php");
	?>
	
	</div>

	<div id=sbar>
     <?php
       include("sideBer.php");
	?>

	</div>

<div id="cont">
	<form method="post" action="../model/login_model.php">
		Email:<br><input type="email" name="u_email" placeholder="Enter your email ..."><br>
		pwd:<br><input type="password" name="password" placeholder="Enter your password ..."><br>
		<input type="submit" name="btn"  value="login">
	</form>

</div>


	<div id="footer">
    <?php
       include("footer.php");
	?>
	</div>

</body>

