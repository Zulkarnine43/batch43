    <script type="text/javascript" src="../js/cart.js"></script>
	<ul>
		<li><a href="index.php"> Home</a> </li>
		<li> <a href="signup.php">Signup</a></li>
		<li> <a href="customer_details.php">Customer details</a></li>
		<li> <a href="add_product.php">add_product</a></li>
        <li> <a href="view_product.php">view_product</a></li>
		<li> <a href="contact.php">Contact</a></li>
		<li> <a href="checkout.php">checkout</a></li>
		<li> <a href="login.php">login</a></li>
		<li><a href="../model/logout_model.php?logout=yes " onclick="return confirm('are you sure to logout')"><?php 
           session_start();
           if(empty($_SESSION['name'])){
            echo " ";
            }else{
                 echo $_SESSION['name'];
             }
		 ?>	
		</a></li>
	</ul>
