-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2020 at 08:02 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shop`
--

-- --------------------------------------------------------

--
-- Table structure for table `cu_info`
--

CREATE TABLE `cu_info` (
  `cu_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  `Confirm_password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cu_info`
--

INSERT INTO `cu_info` (`cu_id`, `name`, `email`, `gender`, `password`, `Confirm_password`) VALUES
(4, 'Ataullah bhuiyan', 'ataullah@gmail.com', 'male', 'MTIz', 'MTIz'),
(6, 'Zulkar Nine', 'zns601@gmail.com', 'male', 'MTIzNDU2', 'MTIzNDU2'),
(7, 'Zulkar Nine', 'zulkarnine43@gmail.com', 'male', 'MTIz', 'MTIz'),
(8, 'Zulkar Nine', 'zns601@gmail.com', 'male', 'MTIz', 'MTIz');

-- --------------------------------------------------------

--
-- Table structure for table `order_info`
--

CREATE TABLE `order_info` (
  `order_id` int(11) NOT NULL,
  `cu_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quentity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product_info`
--

CREATE TABLE `product_info` (
  `product_id` int(11) NOT NULL,
  `p_name` varchar(50) DEFAULT NULL,
  `imagesupload` varchar(255) DEFAULT NULL,
  `quentity` int(11) DEFAULT NULL,
  `price` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_info`
--

INSERT INTO `product_info` (`product_id`, `p_name`, `imagesupload`, `quentity`, `price`) VALUES
(31, 'frog', 'uploads/images (4).jpg', 5, 400),
(32, 'T_shirt', 'uploads/images (3).jpg', 10, 350),
(33, 'frog', 'uploads/images (1).jpg', 5, 450),
(34, 'logo', 'uploads/design.jpg', 5, 100),
(35, 'mobile', 'uploads/ph1.png', 5, 1000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cu_info`
--
ALTER TABLE `cu_info`
  ADD PRIMARY KEY (`cu_id`);

--
-- Indexes for table `order_info`
--
ALTER TABLE `order_info`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `cu_id` (`cu_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product_info`
--
ALTER TABLE `product_info`
  ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cu_info`
--
ALTER TABLE `cu_info`
  MODIFY `cu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `order_info`
--
ALTER TABLE `order_info`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_info`
--
ALTER TABLE `product_info`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_info`
--
ALTER TABLE `order_info`
  ADD CONSTRAINT `order_info_ibfk_1` FOREIGN KEY (`cu_id`) REFERENCES `cu_info` (`cu_id`),
  ADD CONSTRAINT `order_info_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product_info` (`product_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
