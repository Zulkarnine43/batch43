<?php

include("../db/config.php");

$sql="SELECT * FROM product_info";

$result=mysqli_query($con,$sql);


?>