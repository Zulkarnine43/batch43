<?php
include("../db/config.php");

$id=$_GET['id'];

$sql="DELETE FROM cu_info WHERE  cu_id=$id";


$result=mysqli_query($con,$sql);

if($result===TRUE){
	header("location:../view/customer_details.php");
}

?>