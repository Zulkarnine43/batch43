<?php

include("../db/config.php");

$sql="SELECT * FROM cu_info";

$result=mysqli_query($con,$sql);



 echo '<table border="2px" width="100%">';
 echo '<tr><th>id</th><th>name</th><th>email</th><th>gender</th><th>password</th><th>Action</th></tr>';

while($row=mysqli_fetch_array($result)){

	$id=$row['cu_id'];
	$name=$row['name'];
	$email=$row['email'];
	$gender=$row['gender'];
	$password=base64_decode($row['password']);
    echo '<tr>
    <td>'.$id.'</td>
    <td>'.$name.'</td>
    <td>'.$email.'</td>
    <td>'.$gender.'</td>
    <td>'.$password.'</td>
    <td><a href="edit_view_cu.php? id='.$id.'" onclick="return confirm(\'Are you sure want to edit this?\')">Edit</a>
    <a href="../model/delete_cu.php? id='.$id.'" onclick="return confirm(\'Are you sure want to delete this?\')">delete</a></td>
    </tr>';

}

echo '</table>';
?>