<?php

include("../model/view_product_info.php");

?>

 <?php while($row=mysqli_fetch_array($result)){ ?>
    <form method="post" action="../model/checkout_model.php?id=<?php echo $row['product_id'];?>">
    <div class="gallery">
    <a target="_blank" href="">
    <img src="../model/<?php echo $row['imagesupload'];?>" alt="images" style="width:200px; height: 200px">
    </a>
    <div class="desc"><h1 id="n"><?php echo $row['p_name'];?></h1>
    <p class="price" id="p">TK<?php echo $row['price'];?></p>
    <input type="hidden" name="p_name" min="1" value="<?php echo $row['p_name'];?>" >
    <input type="hidden" name="price" min="1" value="<?php echo $row['price'];?>" >
    <input type="number" name="quentity" min="1" value="1" >
    <input type="submit" name="add_cart" value="ADD TO CART">
    </div>
    </div>
    </form>
<?php }?>