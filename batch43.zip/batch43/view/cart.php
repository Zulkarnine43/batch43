
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>

<div id="cont">
    <div class="shopping" id="item">
        <p>Items List</p>
        <p >
            <img width="50px" height="50px" src="images/2.jpg">
            Name: <span id="name"></span> Quentity: <span id="Quetity">0</span> Price: <span id="Price">0</span></p>
        <p>Total Price:<span id="total">0</span></p>

    </div>

</div>


<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

