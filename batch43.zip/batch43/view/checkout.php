<?php

include("../model/view_product_info.php");

?>
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>


<div id="cont">

<?php
include("../model/checkout_model.php");
echo'
<table border="2px" width="100%">
<tr>
<th>product_name</th>
<th>quentity</th>
<th>price</th>
<th>Action</th>
</tr>

<tr>
<td>'.$_SESSION['p_name'].'</td>
<td>'.$_SESSION['quentity'].'</td>
<td>'.$_SESSION['price']*$_SESSION['quentity'].'</td>
<td><button>X</button></td>
</tr>
</table>

<div>

<a href="">checkout<a>

</div>

'

?>

</div>




<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

