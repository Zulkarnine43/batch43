
<body>
<div id="head">
    <?php
    include("header.php");
    ?>

</div>

<div id="menu">
    <?php
    include("menu.php");
    ?>

</div>

<div id=sbar>
    <?php
    include("sideBer.php");
    ?>

</div>

<div id="cont">
    <form method="post" action="../model/add_product_info.php"  enctype="multipart/form-data">
        product-Name:<br><input type="text" name="p_name" placeholder="Enter product name ..."><br>
        Select product image:<br><input type="file" name="image"/><br>
        Quentity:<br><input type="int" name="quentity" placeholder="Enter your Quentity ..."><br>
        price:<br><input type="int" name="price" placeholder="Enter your price ..."><br>
        <input type="submit" name="btn"  value="Submit">
    </form>

</div>


<div id="footer">
    <?php
    include("footer.php");
    ?>
</div>

</body>

