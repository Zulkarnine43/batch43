<?php

include("../db/config.php");



  $sql = "SELECT * FROM cu_info WHERE email='$_POST[u_email]'";
      $result=mysqli_query($con,$sql);

        
        $user = mysqli_fetch_assoc($result);

        if($user){

          session_start();
          $_SESSION['id']=$user['cu_id'];
          $_SESSION['name']=$user['name'];

          header('Location:../view/index.php');
        }
      





?>