<?php
include("../db/config.php");
session_start();

//$id=$_GET['id'];

 if(isset($_POST['add_cart'])){

// $sql="SELECT * FROM product_info WHERE  product_id=$id";
//  echo $result=mysqli_query($con,$sql);

 $value= [
$_SESSION['p_name'] =$_POST['p_name'] ,
$_SESSION['quentity'] =$_POST['quentity'] ,
$_SESSION['price'] =$_POST['price'] 
];

///print_r($value[0]);

// echo $_SESSION['p_name'];
// echo $_SESSION['quentity'];
// echo $_SESSION['price'];
header("location:../view/checkout.php");
 }
 


?>