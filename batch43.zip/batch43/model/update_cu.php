<?php

include("../db/config.php");

$id=$_POST['id'];
$name=$_POST['name'];
$email=$_POST['email'];
$password=base64_encode($_POST['password']);
$Confirm_password=base64_encode($_POST['Confirm_password']);
// echo $id;
// echo $name;
// echo $email;
// echo $password;
// echo $Confirm_password;
$sql=" UPDATE cu_info SET cu_id='$id',name='$name',email='$email',password='$password',Confirm_password='$Confirm_password' WHERE cu_id=$id";

$result=mysqli_query($con,$sql);
// if(! $result){
// 	die ('Error'.mysqli_error($result));
// }

header("Location:../view/customer_details.php");


?>