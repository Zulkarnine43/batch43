
<?php

include("../db/config.php");

$sql="SELECT * FROM product_info";

$result=mysqli_query($con,$sql);



 echo '<table border="2px" width="100%">';
 echo '<tr><th>product-id</th><th>product-name</th><th>product-image</th><th>quentity</th><th>price</th><th>Action</th></tr>';

while($row=mysqli_fetch_array($result)){

	$id=$row['product_id'];
	$p_name=$row['p_name'];
	$image=$row['imagesupload'];
	$quentity=$row['quentity'];
	$price=$row['price'];
    echo '<tr>
    <td>'.$id.'</td>
    <td>'.$p_name.'</td>
    <td>'.$image.'</td>
    <td>'.$quentity.'</td>
    <td>'.$price.'</td>
    <td><a href="" onclick="return confirm(\'Are you sure want to delete this?\')">delete</a></td>
    </tr>';

}

echo '</table>';
?>